package com.austin.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;

@Controller
public class Controllers {

    @RequestMapping("/omikuji")
    public String index() {
        return "index.jsp";
    }

    @RequestMapping(value = "/process", method = RequestMethod.POST)
    public String processForm(HttpSession session,
            @RequestParam(value = "number") Integer number,
            @RequestParam(value = "city") String city,
            @RequestParam(value = "person") String person,
            @RequestParam(value = "livingThing") String livingThing,
            @RequestParam(value = "niceMessage") String niceMessage) {
        session.setAttribute("number", number);
        session.setAttribute("city", city);
        session.setAttribute("person", person);
        session.setAttribute("livingThing", livingThing);
        session.setAttribute("niceMessage", niceMessage);

        return "redirect:/omikuji/show";
    }

    @RequestMapping("/omikuji/show")
    public String showFortune() {
        return "show.jsp";
    }
}
